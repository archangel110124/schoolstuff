﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TalentAgency
{
    public class Contract
    {
        static private int _nextContractNumber = 100;
        private int _contractNumber;
        public int ContractNumber { get { return _contractNumber; } }
        public Agent Agent { get; set; }
        public Artist Artist { get; set; }
        public Label Label { get; set; }

        public Contract()
        {
            _contractNumber = _nextContractNumber++;
        }

        override
        public String ToString()
        {
            return "Contract Number: " + ContractNumber + ", Agent: " + Agent + ", Artist: " + Artist + ", Label: " + Label;
        }
    }
}
