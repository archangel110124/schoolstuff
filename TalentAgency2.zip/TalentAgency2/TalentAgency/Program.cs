﻿using System;

/**
 * Primary Entities for our Agency
 * 
 * Agency
 * Agent
 * Artist
 * Label
 * Contract
 */

namespace TalentAgency
{
    class Program
    {
        static void Main(string[] args)
        {
            bool working = true;
            string choice = "";
            Console.WriteLine("Welcome to our Agency Management System.");
            Agency agency = new Agency("Better yet");

            while (working)
            {
                Console.WriteLine("\nPlease, select your choice.\n");
                Console.WriteLine("1. Create");
                Console.WriteLine("2. Lists");
                Console.WriteLine("3. Assign");
                Console.WriteLine("9. Quit");
                choice = Console.ReadLine();
                switch (choice)
                {
                    case "1":
                        bool creating = true;
                        while (creating)
                        {
                            Console.WriteLine("What do you want to create?");
                            Console.WriteLine("1. Agent");
                            Console.WriteLine("2. Artists");
                            Console.WriteLine("3. Labels");
                            Console.WriteLine("4. Contracts");
                            Console.WriteLine("9. None");
                            String createChoice = "";
                            createChoice = Console.ReadLine();
                            switch (createChoice)
                            {
                                case "1":
                                    Console.WriteLine("Please, enter the first name.");
                                    String agentFirstName = Console.ReadLine();
                                    Console.WriteLine("Please, enter the last name.");
                                    String agentLastName = Console.ReadLine();
                                    Agent newAgent = new Agent(agentFirstName, agentLastName);
                                    Console.WriteLine("We created an agent named :" + newAgent);
                                    agency.addAgent(newAgent);
                                    break;
                                case "2":
                                    Console.WriteLine("Please, enter the first name.");
                                    String artistFirstName = Console.ReadLine();
                                    Console.WriteLine("Please, enter the last name.");
                                    String artistLastName = Console.ReadLine();
                                    Artist newArtist = new Artist(artistFirstName, artistLastName);
                                    Console.WriteLine("We created an artist named :" + newArtist);
                                    agency.addArtist(newArtist);
                                    break;
                                case "3":
                                    Console.WriteLine("Please, enter the name of the Label.");
                                    String labelName = Console.ReadLine();
                                    Label newLabel = new Label(labelName);
                                    Console.WriteLine("We created a label named :" + newLabel);
                                    agency.addLabel(newLabel);
                                    break;
                                case "4":
                                    Contract newContract = new Contract();
                                    agency.addContract(newContract);
                                    Console.WriteLine("A new contract numbered " + newContract.ContractNumber + " has been created.");
                                    break;
                                case "9":
                                    creating = false;
                                    break;
                                default:
                                    break;
                            }
                        }
                        break;
                    case "2":
                        bool listing = true;
                        while(listing)
                        {
                            Console.WriteLine("What do you want to list?");
                            Console.WriteLine("1. Agents");
                            Console.WriteLine("2. Artists");
                            Console.WriteLine("3. Labels");
                            Console.WriteLine("4. Contracts");
                            Console.WriteLine("9. None");
                            String listChoice = "";
                            listChoice = Console.ReadLine();
                            switch(listChoice)
                            {
                                case "1":
                                    Console.WriteLine("The list of agents is");
                                    Console.WriteLine(agency.AgentList);
                                    break;
                                case "2":
                                    Console.WriteLine("The list of artists is");
                                    Console.WriteLine(agency.ArtistList);
                                    break;
                                case "3":
                                    Console.WriteLine("The list of labels is");
                                    Console.WriteLine(agency.LabelList);
                                    break;
                                case "4":
                                    Console.WriteLine("The list of contracts is");
                                    Console.WriteLine(agency.ContractList);
                                    break;
                                case "9":
                                    listing = false;
                                    break;
                                default:
                                    break;
                            }
                        }
                        break;
                    case "3":
                        bool assigning = true;
                        while(assigning)
                        {
                            Console.WriteLine("What do you want to assign?");
                            Console.WriteLine("1. Agents");
                            Console.WriteLine("2. Artists");
                            Console.WriteLine("3. Labels");
                            Console.WriteLine("9. None");
                            String assignChoice = "";
                            assignChoice = Console.ReadLine();
                            switch(assignChoice)
                            {
                                case "1":
                                    Console.WriteLine("Please, enter the contract number");
                                    int contractNumber = Int32.Parse(Console.ReadLine());
                                    Console.WriteLine("Please, enter the Agent's first name");
                                    String agentFirstName = Console.ReadLine();
                                    Console.WriteLine("Please, enter the Agetn's last name");
                                    String agentLastName = Console.ReadLine();
                                    agency.assignAgent(contractNumber, agentFirstName, agentLastName);
                                    break;
                                default:
                                    Console.WriteLine("Invalid choice.");
                                    break;
                            }
                        }
                        break;
                    case "9":
                        working = false;
                        break;
                    default:
                        Console.WriteLine("I don't understand that choice.");
                        break;
                }
            }

            Console.WriteLine("\nThank you for using our AMS.");
        }
    }
}
