﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TalentAgency
{
    interface IPeople
    {
        String FirstName { get; set; }
        String LastName { get; set; }
        String FullName { get; }
    }
}
