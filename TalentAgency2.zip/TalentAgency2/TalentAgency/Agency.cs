﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TalentAgency
{
    public class Agency
    {
        public String Name { get; set; }
        private List<Agent> _agentList;
        private List<Artist> _artistList;
        private List<Label> _labelList;
        private List<Contract> _contractList;

        public String AgentList
        {
            get
            {
                String tempString = "";
                foreach(Agent agent in _agentList)
                {
                    tempString += agent + "\n";
                }
                return tempString;
            }
        }

        public String ArtistList
        {
            get
            {
                String tempString = "";
                foreach(Artist artist in _artistList)
                {
                    tempString += artist + "\n";
                }
                return tempString;
            }
        }

        public String LabelList
        {
            get
            {
                String tempString = "";
                foreach(Label label in _labelList)
                {
                    tempString += label + "\n";
                }
                return tempString;
            }
        }

        public String ContractList
        {
            get
            {
                String tempString = "";
                foreach (Contract contract in _contractList)
                {
                    tempString += contract + "\n";
                }
                return tempString;
            }
        }

        public Agency() : this("No Name") { }
        // Designated Constructor
        public Agency(String name)
        {
            Name = name;
            _agentList = new List<Agent>();
            _artistList = new List<Artist>();
            _labelList = new List<Label>();
            _contractList = new List<Contract>();
        }

        public void addAgent(Agent agent)
        {
            _agentList.Add(agent);
            Console.WriteLine("The count of agents is " + _agentList.Count);
        }

        public void addArtist(Artist artist)
        {
            _artistList.Add(artist);
            Console.WriteLine("The count of artists is " + _artistList.Count);
        }

        public void addLabel(Label label)
        {
            _labelList.Add(label);
            Console.WriteLine("The count of labels is " + _labelList.Count);
        }

        public void addContract(Contract contract)
        {
            _contractList.Add(contract);
        }

        public void assignAgent(int contractNumber, String agentFirstName, String agentLastName)
        {
            // Assignment 02
            // Find the contract by the contractNumber
            // Find the Agent by the first name and last name
            // Assign agent to contract.
            // contract.Agent = agent; This should be the last line
        }
    }
}
