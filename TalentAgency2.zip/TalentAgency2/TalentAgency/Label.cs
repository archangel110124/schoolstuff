﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TalentAgency
{
    public class Label
    {
        public String Name { get; set; }
        public String Address { get; set; }

        public Label() : this("No Name") { }
        public Label(String name)
        {
            Name = name;
            Address = "No Address";
        }

        override
        public String ToString()
        {
            return Name;
        }
    }
}
