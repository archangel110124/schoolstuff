﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TalentAgency
{
    public class Agent : IPeople
    {
        public String FirstName { get; set; }
        public String LastName { get; set; }
        public String FullName { get { return FirstName + " " + LastName; } }

        public Agent() : this("No First Name") { }
        public Agent(String firstName) : this(firstName, "No Last Name") { }
        // Designated Constructor
        public Agent(String firstName, String lastName)
        {
            FirstName = firstName;
            LastName = lastName;
        }

        override
        public String ToString()
        {
            return LastName + ", " + FirstName;
        }
    }
}
