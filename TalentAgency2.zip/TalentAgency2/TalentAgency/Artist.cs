﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TalentAgency
{
    public class Artist : IPeople
    {
        public String FirstName { get; set; }
        public String LastName { get; set; }
        public String FullName { get { return FirstName + " " + LastName; } }

        public Artist() : this("No First Name") { }
        public Artist(String firstName) : this(firstName, "No Last Name") { }
        public Artist(String firstName, String lastName)
        {
            FirstName = firstName;
            LastName = lastName;
        }

        override
        public String ToString()
        {
            return LastName + ", " + FirstName;
        }
    }
}
